import { ProductList } from "@/components/products";

export default function Home() {
  return (
    <main>
      <ProductList/>
    </main>
  );
}
