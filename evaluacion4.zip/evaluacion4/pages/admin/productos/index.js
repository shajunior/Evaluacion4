export default function Home() {
    return (
      <div>
        hola mundo
      </div>
    );
  }