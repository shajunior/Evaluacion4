const data = {
    
        "products": [
          {
            "SKU": "p0003.jpg",
            "name": "juego de dama",
            "description": "Tablero para el juego de damas. Incluye un tablero y 24 fichas repartidas entre el color blanco y negro. Tablero se convierte en maleta para guardar las fichas.",
            "category": "Juego de tablero",
            "disponible_en": "Santiago centro",
            "stock": 11,
            "tiempo_de_juego": 2
          },
          {
            "SKU": "p0004.png",
            "name": "monopoly",
            "description": "Tablero para el juego de damas. Incluye un tablero y 24 fichas repartidas entre el color blanco y negro. Tablero se convierte en maleta para guardar las fichas.",
            "category": "Juego de tablero",
            "disponible_en": "Santiago centro",
            "stock": 12,
            "tiempo_de_juego": 6
          },
          {
            "SKU": "p0005.png",
            "name": "juego de dama",
            "description": "Tablero para el juego de damas. Incluye un tablero y 24 fichas repartidas entre el color blanco y negro. Tablero se convierte en maleta para guardar las fichas.",
            "category": "Juego de tablero",
            "disponible_en": "Santiago centro",
            "stock": 13,
            "tiempo_de_juego": 4
          },
          {
            "SKU": "p0006.png",
            "name": "juego de dama",
            "description": "Tablero para el juego de damas. Incluye un tablero y 24 fichas repartidas entre el color blanco y negro. Tablero se convierte en maleta para guardar las fichas.",
            "category": "Juego de tablero",
            "disponible_en": "Santiago centro",
            "stock": 14,
            "tiempo_de_juego": 3
          },
          {
            "SKU": "p0007.png",
            "name": "juego de dama",
            "description": "Tablero para el juego de damas. Incluye un tablero y 24 fichas repartidas entre el color blanco y negro. Tablero se convierte en maleta para guardar las fichas.",
            "category": "Juego de tablero",
            "disponible_en": "Santiago centro",
            "stock": 14,
            "tiempo_de_juego": 3
          },
          {
            "SKU": "p0008.png",
            "name": "monopoly",
            "description": "Con Monopoly disfruta de momentos especiales con tu familia y amigos. Juega, diviértete y vive momentos inolvidables.",
            "category": "Juego de tablero",
            "disponible_en": "Santiago centro",
            "stock": 14,
            "tiempo_de_juego": 3
          },
          {
            "SKU": "p0009.png",
            "name": "juego de dama",
            "description": "Tablero para el juego de damas. Incluye un tablero y 24 fichas repartidas entre el color blanco y negro. Tablero se convierte en maleta para guardar las fichas.",
            "category": "Juego de tablero",
            "disponible_en": "Santiago centro",
            "stock": 14,
            "tiempo_de_juego": 3
          },
          {
            "SKU": "p0010.png",
            "name": "monopoly",
            "description": "Con Monopoly disfruta de momentos especiales con tu familia y amigos. Juega, diviértete y vive momentos inolvidables.",
            "category": "Juego de tablero",
            "disponible_en": "Santiago centro",
            "stock": 14,
            "tiempo_de_juego": 3
          }
        ]
      }