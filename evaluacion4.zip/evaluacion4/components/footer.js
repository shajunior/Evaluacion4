export default function Footer() {
    return (
        <footer className="grid p-1 bg-stone-600 text-white text-center lg:max-w-12xl lg:w-full lg:mb-0 lg:grid-cols-1 lg:text-center my-8">
            Creada por InacapLudi. 2024
        </footer>
    )
}