import Navbar from './navbar'
import Footer from './footer'
import { Inter } from "next/font/google";
const inter = Inter({ subsets: ["latin"] });

export default function Layout({ children }) {
  return (
    <main className={`flex min-h-screen flex-col justify-between ${inter.className}`}>
      <Navbar />
      <div className="flex grow">
        {children}
      </div>
      <Footer />
    </main>
  )
}