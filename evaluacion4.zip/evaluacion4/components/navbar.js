import { useState } from 'react';
import Inacap from '@/public/logo.png'
import Image from "next/image";
import Link from "next/link";


export default function NavBar() {
    const [open, setOpen] = useState(false)



    

    const navigation = [
        {
            href: "/",
            name: "Página Principal"
        },
        {
            href: "/admin/posts",
            name: "Administración"
        },
        {
            href: "/about",
            name: "Sobre el blog"
        },
        {
            href: "/api/posts",
            name: "Datos JSON"
        }
    ]

    return (
        <>
            <header className="flex flex-row justify-between bg-red-600 p-4 border-stone-300 text-center">
                <Image src={Inacap} width={150} height={150} />
                
                <button  class="h-[56.25px] hover:cursor-pointer w-max flex gap-2 items-center justify-center">
                    <Link href={"/admin/productos"}>
                
                    <span class="font-semibold text-white">Iniciar sesion</span>
                    <svg class="max-h-[56.25px] fill-white" data-slot="icon" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path clipRule="evenodd" fillRule="evenodd" d="M7.5 6a4.5 4.5 0 1 1 9 0 4.5 4.5 0 0 1-9 0ZM3.751 20.105a8.25 8.25 0 0 1 16.498 0 .75.75 0 0 1-.437.695A18.683 18.683 0 0 1 12 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 0 1-.437-.695Z"></path>
                    </svg>
                    </Link>
                </button>
            </header>
            {
                open ?
                    <div className='absolute top-0 right-0 w-[250px] h-[250px] border'>
                        Login Form
                    </div>
                    :
                    <div>&nbsp;</div>
            }
        </>
    )
}