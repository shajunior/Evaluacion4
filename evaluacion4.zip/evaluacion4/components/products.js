import { useState, useEffect } from 'react'
 

export function ProductList() {
    const [data, setData] = useState(null)
    const [isLoading, setLoading] = useState(true)

    useEffect(() => {
        fetch('/api/product')
            .then((res) => res.json())
            .then((data) => {
                setData(data)
                setLoading(false)
            })
    }, [])

    if (isLoading) return <p>Cargando productos...</p>
    if (!data || data.length == 0) return <p>No hay productos disponibles</p>

    return (
        <section className='grid gap-4 p-4 grid-cols-4'>
            {data.map((producto) => (
                <div key={producto.code} className='border p-4 flex flex-col gap-2'>
                    <img className='max-h-[220px] object-scale-down' src={producto.image} alt={producto.name} />
                    <p className='text-stone-500'><span>SKU: </span>{producto.code}</p>
                    <h4 className='text-xl font-medium'>{producto.name}</h4>
                    <p className='text-justify'>{producto.description}</p>
                    <span className='bg-red-600 rounded-md p-1 w-fit text-white'>{producto.category}</span>
                    <p className='flex items-center justify-start gap-2'>
                        <svg className='h-6 w-6 fill-red-500' data-slot="icon" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                            <path clipRule="evenodd" fillRule="evenodd" d="m11.54 22.351.07.04.028.016a.76.76 0 0 0 .723 0l.028-.015.071-.041a16.975 16.975 0 0 0 1.144-.742 19.58 19.58 0 0 0 2.683-2.282c1.944-1.99 3.963-4.98 3.963-8.827a8.25 8.25 0 0 0-16.5 0c0 3.846 2.02 6.837 3.963 8.827a19.58 19.58 0 0 0 2.682 2.282 16.975 16.975 0 0 0 1.145.742ZM12 13.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"></path>
                        </svg>
                        <span className='text-lg font-medium text-red-500'>Disponible en: {producto.location}</span>
                    </p>
                    <p><span>Stock: </span>{producto.availability}</p>
                    <p><span>Tiempo de juego: </span>{producto.timebox}</p>
                </div>
            ))}
        </section>
    )
} 